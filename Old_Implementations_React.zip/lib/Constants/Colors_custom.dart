import 'dart:ui';

class Colors_custom {
  static const Color bgCol = Color('A020F0');
  static const Color Col1 = Color('A020F1');
  static const Color Col2 = Color('A020F2');
  static const Color Col3 = Color('A020F3');
  static const Color Col4 = Color('A020F4');
  static const Color Col5 = Color('A020F5');
}
